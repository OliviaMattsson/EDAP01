package models;



public class RobotSim {
	/*
	 *  ********************* YOUR TASK ******************
	 *  
	 *  Implement the robot simulator:
	 *  - the robot should be able to move one step according to the motion model 
	 *  i.e., produce a new pose based on the old one
	 *  - the simulation should also contain a sensor reading method, that generates a 
	 *  sensor reading based on the current (true) state of the system and the sensor model
	 */

}